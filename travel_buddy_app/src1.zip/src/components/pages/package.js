import React from "react";

const Packages = () => {
    return (
        <h1>Contcat Page</h1>
    )
}
export default Packages;