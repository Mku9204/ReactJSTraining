import React from "react";

const Places = () => {
    return (
        <h1>Contcat Page</h1>
    )
}
export default Places;