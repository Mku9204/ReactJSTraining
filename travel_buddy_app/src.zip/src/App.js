import './App.css';
import NavBar from './components/navbar/navbar';
import Card1 from './components/card/card';
import banner_bg from './assests/img/banner_bg.png'
import Vector from './assests/icons/Vector.svg'
import { Container } from '@mui/material';
import Topvist from './components/topvist/topvist';
import Subnav from './components/subnav/subnav';
import A1 from './assests/img/a1.png'
import A2 from './assests/img/a2.png'
import A3 from './assests/img/a3.png'
import A4 from './assests/img/a4.png'
function App() {
  return (
    <div className="App">
      <Container maxWidth='false' fullWidth>
        <NavBar vector={Vector} />
        <Card1 image={banner_bg} />
        <Subnav />
        <Topvist a1={A1} a2={A2} a3={A3} a4={A4} />
        <Card1 image={banner_bg} />
      </Container>
    </div>
  );
}

export default App;
