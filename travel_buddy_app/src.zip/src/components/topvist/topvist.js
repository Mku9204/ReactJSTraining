import { Card, CardActionArea, CardMedia, Grid, Typography } from "@mui/material";
import { Container } from "@mui/system";

import React from "react";

const Topvist = (props) => {
    return (
        <Container fixed>
            <Typography
                variant="h4"
                component="h2"
                sx={{
                    fontFamily: "Inter",
                    fontStyle: "normal",
                    fontWeight: "600",
                    fontSize: "36px",
                    lineHeight: "44px",
                    textAlign: "center",
                    letterSpacing: "0.05em",
                    color: "#041562",
                    paddingTop: '60px'
                }}
            >
                Top Places To Visit
            </Typography>

            <Typography
                variant="caption"
                display="block"
                gutterBottom
                sx={{
                    fontFamily: "Inter",
                    fontStyle: "normal",
                    fontWeight: "400",
                    fontSize: "18px",
                    lineHeight: "22px",
                    textAlign: "center",
                    letterSpacing: "0.05em",
                    color: "#626262",
                    paddingBottom: '40px'
                }}
            >
                The Best Place to Stay in Indonesia
            </Typography>
            <Grid container rowSpacing={2} columnSpacing={{ xs: 1, sm: 2, md: 3 }}
                sx={{

                }}
            >
                <Grid item xs={6}>
                    <Card sx={{
                    }}>
                        <CardMedia
                            component="img"
                            width='500px'
                            height='400px'
                            image={props.a1}
                            alt="green iguana"
                        />
                    </Card>
                </Grid>
                <Grid item xs={6}>
                    <Card >
                        <CardMedia
                            component="img"
                            width='500px'
                            height='400px'
                            image={props.a2}
                            alt="green iguana"
                        />
                    </Card>
                </Grid>
                <Grid item xs={6}>
                    <Card >
                        <CardMedia
                            component="img"
                            width='500px'
                            height='400px'
                            image={props.a3}
                            alt="green iguana"
                        />
                    </Card>
                </Grid>
                <Grid item xs={6}>
                    <Card >
                        <CardMedia
                            component="img"
                            width='500px'
                            height='400px'
                            image={props.a4}
                            alt="green iguana"
                        />
                    </Card>
                </Grid>
            </Grid>
        </Container >
    )
}
export default Topvist;